define("epi-cms/contentediting/command/BlockInlineEdit", [
    "dojo/_base/declare",
    "dojo/on",
    "dojo/topic",
    "dojo/when",
    "dojox/html/entities",
    "epi/dependency",
    "epi/shell/TypeDescriptorManager",
    "epi/shell/DestroyableByKey",
    "epi-cms/core/ContentReference",
    "epi-cms/contentediting/ContentActionSupport",
    "epi/shell/command/_Command",
    "epi/shell/postMessage",
    "epi-cms/contentediting/DialogPositionAdjust",
    "epi-cms/contentediting/inline-editing/InlineEditBlockDialog",
    "epi-cms/contentediting/inline-editing/BlockEditFormContainer",
    "epi-cms/contentediting/command/BlockInlinePublish",
    "epi-cms/contentediting/command/BlockInlineReadyForReview",
    "epi-cms/contentediting/command/BlockInlineReadyToPublish",
    "epi-cms/contentediting/EditNotifications",
    "epi-cms/contentediting/NotificationBar",
    "epi/i18n!epi/cms/nls/episerver.cms.contentediting.inlineediting",
    "epi/i18n!epi/cms/nls/episerver.cms.contentediting.toolbar.buttons",
    "epi/i18n!epi/nls/episerver.cms.contentapproval.command.requestapproval"
], function (declare, on, topic, when, htmlEntities, dependency, TypeDescriptorManager, DestroyableByKey, ContentReference, ContentActionSupport, _Command, postMessage, DialogPositionAdjust, InlineEditBlockDialog, BlockEditFormContainer, InlinePublish, InlineReadyForReview, InlineReadyToPublish, EditNotifications, NotificationBar, resources, toolbarButtonsRes, requestapprovalRes) {
    // In quick edit dialog we need to handle save errors
    var BlockInlineEditDialog = declare([InlineEditBlockDialog], {
        _onSubmit: function () {
            if (!this.validate()) {
                return;
            }
            // when submitting inline edit dialog we need to check if errors were not returned from server
            when(this.waitForSubmitAction()).then(function () {
                this.execute(this.get("value"));
                this.hide();
            }.bind(this)).otherwise(function (result) {
                this.showError(result);
            }.bind(this));
        },
        /**
         * Parse and show error messages in notification bar
         * @param response
         */
        showError: function (response) {
            function getErrorText() {
                if (Array.isArray(response)) {
                    var responseErrors = response.map(function (error) {
                        return error.errorMessage;
                    });
                    return responseErrors.join(", ");
                }
                if (response.responseText) {
                    try {
                        var errors = JSON.parse(response.responseText);
                        if (errors && errors.length) {
                            return errors.map(function (error) {
                                return error.errorMessage;
                            }).filter(function (error) {
                                return !!error;
                            }).join(", ");
                        }
                    }
                    catch (e) {
                        console.error("Cannot parse response", e);
                    }
                }
                return resources.saveerror;
            }
            if (this._errorNotification) {
                this.notificationBar.remove(this._errorNotification);
            }
            this._errorNotification = {
                content: getErrorText()
            };
            this.notificationBar.add(this._errorNotification);
        },
        /**
         * Callback method overridden in function
         * @returns {boolean}
         */
        waitForSubmitAction: function () {
            return true;
        }
    });
    return declare([_Command, DestroyableByKey], {
        // summary:
        //      Inline-edit command for the Block component
        // tags:
        //      internal xproduct
        label: resources.inlineblockedit,
        iconClass: "epi-iconPenQuick",
        _dialog: null,
        // suppressOverlayAdjustments: [public] Boolean
        //      Flag which indicates that all overlay adjustments should not be performed. It might be useful when showing another overlay or dialog (e.g. TinyMCE full screen)
        suppressOverlayAdjustments: false,
        // summary:
        //      List of statuses, of which content cannot be edit
        ignoredEditStatuses: [
            ContentActionSupport.versionStatus.CheckedIn,
            ContentActionSupport.versionStatus.PreviouslyPublished,
            ContentActionSupport.versionStatus.DelayedPublish,
            ContentActionSupport.versionStatus.AwaitingApproval
        ],
        postscript: function () {
            this.inherited(arguments);
            this._dialogPositionAdjust = new DialogPositionAdjust();
            this.own(this._dialogPositionAdjust);
            this._enhancedStore = dependency.resolve("epi.storeregistry").get("epi.cms.latestcontentversion");
            this.own(topic.subscribe("/epi/cms/content/statuschange/", function (status, contentIdentity) {
                if (!this.model || !this.model.contentLink) {
                    return;
                }
                var updatedContentId = new ContentReference(contentIdentity.id).createVersionUnspecificReference();
                var currentModelId = new ContentReference(this.model.contentLink).createVersionUnspecificReference();
                if (ContentReference.compareIgnoreVersion(updatedContentId, currentModelId)) {
                    this._enhancedStore.query(currentModelId.toString()).then(function (contentData) {
                        this._refreshContentSettings(contentData);
                    }.bind(this));
                }
            }.bind(this)));
        },
        _execute: function () {
            // summary:
            //    Open the inline edit block dialog
            // tags:
            //      protected
            var dialog = this._dialog = new BlockInlineEditDialog({
                title: htmlEntities.encode(this.model.name),
                mainCommand: this.mainCommand,
                suppressOverlayAdjustments: this.suppressOverlayAdjustments
            });
            var _this = this;
            var form;
            function updateMainCommandVisibility() {
                if (!dialog) {
                    return;
                }
                // the mainButton is always visible
                dialog.toggleMainButton(true);
                dialog.toggleDisabledMainButton(!(_this.mainCommand.get("canExecute") || form.get("isDirty")));
                dialog.toggleDisabledSaveButton(!form.get("isDirty"));
            }
            var isAvailableHandle = this.mainCommand.watch("isAvailable", updateMainCommandVisibility.bind(this));
            var canExecuteHandle = this.mainCommand.watch("canExecute", updateMainCommandVisibility.bind(this));
            form = new BlockEditFormContainer({}, dialog.content, "last");
            form.set("contentLink", this.model.contentLink).then(function (formContentData) {
                this.mainCommand.set("model", this.model);
                // manually trigger the _onModelChange in order to fetch contentdata from store and calculate if the mainCommand should be available or not.
                this.mainCommand._onModelChange();
                updateMainCommandVisibility();
                _this.set("isPartOfActiveApproval", formContentData.isPartOfActiveApproval);
            }.bind(this));
            var formCreatedHandle = on(form, "FormCreated", function () {
                if (form.model && !form._model.canChangeContent()) {
                    dialog.hideSaveButton();
                    dialog.set("closeText", "Close");
                }
                dialog.show();
                updateMainCommandVisibility();
                this._createNotificationsBar(dialog, form);
            }.bind(this));
            function getModelErrors() {
                if (form._model.validationErrors && form._model.validationErrors.length > 0) {
                    var errors = form._model.validationErrors.filter(function (error) {
                        return error.severity === form._model.validator.severity.error;
                    });
                    return errors;
                }
            }
            var _mainCommand = this.mainCommand;
            var onChangeHandle = on(form, "isDirty", updateMainCommandVisibility.bind(form));
            dialog.waitForSubmitAction = function () {
                /**
                 * handle both scenarios when request is rejected
                 * but also when validationErrors are set
                 */
                return new Promise(function (resolve, reject) {
                    when(form.saveForm()).then(function () {
                        var errors = getModelErrors();
                        if (errors && errors.length > 0) {
                            reject(errors);
                            return;
                        }
                        resolve();
                    }).otherwise(function (error) {
                        reject(error);
                    });
                });
            };
            var mainCommandHandle = on(dialog, "MainCommand", function () {
                if (!this.validate()) {
                    return;
                }
                _this._listenToContentIndexed(_this.model.contentLink, dialog, function () {
                    return new Promise(function (resolve, reject) {
                        when(_mainCommand.tryToSaveAndExecute(form)).then(function () {
                            var errors = getModelErrors();
                            if (errors && errors.length > 0) {
                                dialog.showError(errors);
                                reject();
                                return;
                            }
                            resolve();
                        }).otherwise(function (error) {
                            dialog.showError(error);
                            reject();
                        });
                    });
                });
            });
            var closeHandle = on(dialog, "hide", function () {
                this._dialogPositionAdjust.cleanup();
                form.destroy();
                this.mainCommand.destroy();
                closeHandle.remove();
                formCreatedHandle.remove();
                onChangeHandle.remove();
                mainCommandHandle.remove();
                isAvailableHandle.remove();
                canExecuteHandle.remove();
                this._dialog = null;
            }.bind(this));
            this._dialogPositionAdjust.adjustDialogPosition(dialog);
        },
        _createNotificationsBar: function (dialog, form) {
            var dialogContentEl = document.createElement("div");
            dialog.containerNode.prepend(dialogContentEl);
            var notificationBar = new NotificationBar();
            dialog.own(notificationBar);
            notificationBar.placeAt(dialogContentEl);
            var editNotifications = new EditNotifications();
            dialog.own(editNotifications);
            dialog.own(editNotifications.on("changed", function (e) {
                if (e.oldValue) {
                    notificationBar.remove(e.oldValue);
                }
                if (e.newValue && e.newValue.content) {
                    var availableNotificationIndex = e.notification ? editNotifications.getAvailableNotificationIndex(e.notification) : 0;
                    notificationBar.add(e.newValue, availableNotificationIndex);
                }
            }.bind(this)));
            this._viewSettingsManager = this._viewSettingsManager || dependency.resolve("epi.viewsettingsmanager");
            editNotifications.updateSettings({ viewModel: form._model, viewSetting: this._viewSettingsManager });
            editNotifications.update(form._model.contentData, form._context, form._model, true);
            dialog.notificationBar = notificationBar;
        },
        _getContentData: function () {
            // summary:
            //      Get the latest content version
            //
            // tags:
            //      protected
            return this._enhancedStore.query({ id: this.model.contentLink, keepversion: true });
        },
        updateModel: function (model) {
            // summary:
            //      Updates model and returns result from onModelChange callback
            // tags:
            //      internal
            this.model = model;
            return this._onModelChange();
        },
        _onModelChange: function () {
            // summary:
            //      Updates isAvailable after the model has been updated.
            // tags:
            //      protected
            this.inherited(arguments);
            if (this.model instanceof Array) {
                // this command should be available only if one item selected
                // because it should be disabled when multiple blocks are selected
                // like in Assets pane
                if (this.model.length === 1) {
                    this.model = this.model[0];
                }
                else {
                    this.model = null;
                }
            }
            if (!this.model) {
                this.set("canExecute", false);
                return;
            }
            if (!this.model || this.model.inlineBlockData ||
                !TypeDescriptorManager.isBaseTypeIdentifier(this.model.typeIdentifier, "episerver.core.blockdata")) {
                this.set("isAvailable", false);
                return;
            }
            if (this.model.isOverlayInitialized === false) {
                return;
            }
            return when(this._getContentData()).then(function (contentData) {
                this._refreshContentSettings(contentData);
            }.bind(this));
        },
        _refreshContentSettings: function (contentData) {
            // summary:
            //      Update the content settings
            // tags:
            //      protected
            // contentData == null when it doesn't have a content version in the current language
            if (contentData == null) {
                this.set("isAvailable", false);
                this.set("canExecute", false);
                return;
            }
            this.set("isAvailable", true);
            var hasAccessRights = ContentActionSupport.hasAccess(contentData.accessMask, ContentActionSupport.accessLevel.Edit);
            var hasProviderSupportForEditing = ContentActionSupport.hasProviderCapability(contentData.providerCapabilityMask, ContentActionSupport.providerCapabilities.Edit);
            var isDeleted = contentData.isDeleted;
            this.inUseNotificationManager = this.inUseNotificationManager || dependency.resolve("epi.cms.contentediting.inUseNotificationManager");
            var isInUse = this.inUseNotificationManager.hasInUseNotificationWarning(contentData.inUseNotifications);
            var canExecute = (this.ignoredEditStatuses.indexOf(contentData.status) === -1) && hasAccessRights && hasProviderSupportForEditing && !isDeleted && !isInUse;
            this.set("canExecute", canExecute);
            if (canExecute) {
                this._calculateMainButtonCommand(contentData);
            }
        },
        _calculateMainButtonCommand: function (contentData) {
            // summary:
            //      Calculate to see which command is going to be the main command
            //      in the  InlineEditBlockDialog for the given contentData
            if (contentData.isPartOfActiveApproval) {
                // the content is part of an active approval, therefore the command Ready for Review is the main command
                this.mainCommand = new InlineReadyForReview({
                    commandType: "inline-edit-form",
                    label: requestapprovalRes.label
                });
            }
            else if (ContentActionSupport.hasAccess(contentData.accessMask, ContentActionSupport.accessLevel.Publish)) {
                // user has Publish access right, so the Publish is the main command
                // if the current content has a published version,
                // the button should be "Publish Changes", otherwise "Publish"
                var publishLabel;
                if (contentData.hasPublishedVersion) {
                    publishLabel = toolbarButtonsRes.publishchanges.label;
                }
                else {
                    publishLabel = toolbarButtonsRes.publish.label;
                }
                this.mainCommand = new InlinePublish({
                    commandType: "inline-edit-form",
                    label: publishLabel
                });
            }
            else {
                // Ready to Publish command is the main command
                this.mainCommand = new InlineReadyToPublish({
                    commandType: "inline-edit-form",
                    label: toolbarButtonsRes.sendforreview.label
                });
            }
        },
        /**
         * We will get notification about block indexed, but we won't get notification that parent page was indexed
         * We will listen to contentSaved event and notify parent page that it should be reloaded
         */
        _listenToContentIndexed: function (contentLink, dialog, callback) {
            var topicHandle = null;
            var timeoutHandle = null;
            var publishTimeoutHandle = null;
            // clear all handles to topic and timeout
            function clearHandles() {
                if (topicHandle) {
                    topicHandle.remove();
                    topicHandle = null;
                }
                if (timeoutHandle) {
                    clearTimeout(timeoutHandle);
                    timeoutHandle = null;
                }
                if (publishTimeoutHandle) {
                    clearTimeout(publishTimeoutHandle);
                    publishTimeoutHandle = null;
                }
            }
            // wait for block indexed and then refresh the page
            var isContentIndexed = false;
            topicHandle = topic.subscribe("content-index", function (data) {
                var savingContentId = new ContentReference(contentLink).createVersionUnspecificReference();
                var indexedContentId = new ContentReference(data.contentLink).createVersionUnspecificReference();
                // if current block was indexed
                if (ContentReference.compareIgnoreVersion(savingContentId, indexedContentId)) {
                    isContentIndexed = true;
                    clearHandles();
                    // we don't get event from server that parent page was indexed
                    // we need to refresh it after a while
                    setTimeout(function () {
                        postMessage.publish("contentSaved", {
                            contentLink: data.currentContentLink
                        });
                    }, 1000);
                }
            });
            // if the published was not called for four seconds then clear handles
            timeoutHandle = setTimeout(function () {
                clearHandles();
            }, 4000);
            // publish the page
            when(callback()).then(function () {
                if (!isContentIndexed) {
                    // wait maximum three seconds after page was published and then remove the handle
                    publishTimeoutHandle = setTimeout(function () {
                        clearHandles();
                        if (!isContentIndexed) {
                            dialog.hide();
                        }
                    }, 3000);
                }
                else {
                    dialog.hide();
                }
            }).otherwise(function () {
                clearHandles();
            });
        }
    });
});
