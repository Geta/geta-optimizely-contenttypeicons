define("content-graph/SynchronizeCommand", [
  "dojo/_base/declare",
  "dojo/when",
  "dojo/_base/lang",

  "epi/shell/command/_Command",
  "epi/dependency",
  "epi-cms/_ContentContextMixin",
  // resources
  "epi/i18n!epi/cms/nls/optimizely.contentgraph.editview"
],
  function (declare, when, lang, _Command, dependency, _ContentContextMixin, resources) {
    return declare([_Command, _ContentContextMixin],
    {
      // tags:
      //      public

      name: "Synchronize",
      label: resources.synchronize,
      iconClass: "epi-iconRight",
      canExecute: true,
      order: 10000,

      constructor: function () {
        var registry = dependency.resolve("epi.storeregistry");
        this.store = this.store || registry.get("epi-contentgraph.contentindexing");
      },

      _execute: function () {
        // summary:
        //      Trigger when user click on the menu item.
        // tags:
        //      protected

        when(this.getCurrentContext(), lang.hitch(this, function (context) {
          when(this.store.executeMethod("SynchronizeContent", null, context.id), this.updateSyncStatus.bind(this));
        }));
      },

      _onModelChange: function () {
        this.updateSyncStatus()
      },

      //returns true if the update status is successful (200 status returned from server)
      //returns false if the update failed (401 error, for example)
      updateSyncStatus: function () {
        return when(this.getCurrentContext(), lang.hitch(this, function (context) {
          return when(this.store.executeMethod("getSyncStatus", null, context.id), lang.hitch(this, function (res) {
             this.set('iconClass', res ? "epi-iconRight" : "epi-iconUpload");
             return true;//status update is successful
            }),
            function(err) {
              return false;//status update failed due to server errors
            }
          )
        }));
      }
    });
  }
);
