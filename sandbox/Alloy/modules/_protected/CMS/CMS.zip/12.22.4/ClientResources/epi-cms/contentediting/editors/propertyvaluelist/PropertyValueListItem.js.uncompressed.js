require({cache:{
'url:epi-cms/contentediting/editors/propertyvaluelist/templates/PropertyValueListItem.html':"<div class=\"epi-property-value-list__item\">\r\n    <div class=\"header\">\r\n        <div class=\"container-node\" data-dojo-attach-point=\"containerNode\"></div>\r\n        <span class=\"dijitInline dijitIcon epi-iconContextMenu\"></span>\r\n    </div>\r\n</div>\r\n",
'url:epi-cms/contentediting/editors/propertyvaluelist/templates/CollapsiblePropertyValueListItem.html':"<div class=\"epi-property-value-list__item collapsible\">\r\n    <div class=\"epi-property-value-list__index\"></div>\r\n    <div class=\"epi-property-value-list__content\">\r\n        <div class=\"header\">\r\n            <div class=\"title\">\r\n                <div class=\"expander\" data-dojo-attach-point=\"expander\">\r\n                    <span class=\"dijitArrowButtonInner dijitRightArrowButton\" data-dojo-attach-point=\"expanderIcon\"></span>\r\n                    <span data-dojo-attach-point=\"headerNode\"></span>\r\n                </div>\r\n            </div>\r\n            <span class=\"dijitIcon epi-iconContextMenu\"></span>\r\n        </div>\r\n        <div class=\"block-data-container hidden\" data-dojo-attach-point=\"containerNode\"></div>\r\n    </div>\r\n</div>\r\n"}});
﻿define("epi-cms/contentediting/editors/propertyvaluelist/PropertyValueListItem", [
    // dojo
    "dojo/_base/declare",
    "dojo/on",
    // dijit
    "dijit/_WidgetBase",
    "dijit/_Container",
    "dijit/_TemplatedMixin",
    "epi/shell/widget/_FocusableMixin",
    // resources
    "dojo/text!./templates/PropertyValueListItem.html",
    "dojo/text!./templates/CollapsiblePropertyValueListItem.html"
], function (
    // dojo
    declare,
    on,
    // dijit
    _WidgetBase,
    _Container,
    _TemplatedMixin,
    _FocusableMixin,
    // resources
    template,
    collapsibleTemplate
) {
    return declare([_WidgetBase, _Container, _TemplatedMixin, _FocusableMixin], {
        // summary:
        //      The view for the PropertyValueListItem. Responsible for setting
        //      the editor and handle focus
        // tags:
        //      internal

        // widgetFactory: [readonly] epi/shell/widget/WidgetFactory
        //      The widget factory used when creating the editor
        widgetFactory: null,

        // editorDefinition: [readonly] Object
        //      The editor metadata used when creating the editor
        editorDefinition: null,

        // isComplexType: [readonly] Boolean
        //      Is this a list of complex property types
        isComplexType: null,

        // isFullWidth: [readonly] Boolean
        //      Display full width
        isFullWidth: null,

        postMixInProperties: function () {
            this.inherited(arguments);

            this.templateString = this.isComplexType ? collapsibleTemplate : template;
        },

        buildRendering: function () {
            this.inherited(arguments);

            // Create the editor using the widget factory
            this._createDeferred = this.widgetFactory.createWidgets(this, this.editorDefinition, false).then(function (widgets) {
                this.editor = widgets[0];
                this.editor.set("isListItem", true);

                // Hook up the change event on the editor and forward it to wrapper
                this.own(this.editor.on("change", function (editorValue) {
                    if (typeof this.editor.isValid === "function" && !this.editor.isValid()) {
                        return;
                    }
                    this.onChange(editorValue);
                }.bind(this)));

                this.own(this.editor.on("focus", function () {
                    this.onStartEdit();
                }.bind(this)));

                this.own(this.editor.on("blur", function () {
                    this.onStopEdit();
                }.bind(this)));

                if (this.isComplexType) {
                    this.headerNode.innerHTML = this.itemTypeName;
                    this.own(on(this.expander, "click", this.expand.bind(this)));
                } else {
                    if (this.isFullWidth) {
                        this.containerNode.classList.add("full-width");
                    }
                }
            }.bind(this));
        },

        getDisplayedValue: function () {
            if (!this.editor) {
                return "";
            }

            return this.editor.displayedValue;
        },

        expand: function () {
            if (!this.isComplexType) {
                return;
            }
            this.expanderIcon.classList.toggle("dijitRightArrowButton");
            this.containerNode.classList.toggle("hidden");
        },

        onChange: function (value) {
            // summary:
            //      callback method called when the value has changed
            //  tags:
            //      public
        },

        onStartEdit: function () {
            // summary:
            //      callback method called when editor is activated
            //  tags:
            //      public
        },

        onStopEdit: function () {
            // summary:
            //      callback method called when editor is no longer active
            //  tags:
            //      public
        },

        focus: function () {
            // summary:
            //      Focus the editor
            // tags:
            //      public

            this._createDeferred && this._createDeferred.then(function () {
                this.editor.focus && this.editor.focus();
            }.bind(this));
        }
    });
});
